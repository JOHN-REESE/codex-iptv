# IPTV Stream Sniffer

This repository can inspect a webpage, capture live stream URLs that appear in the page or network traffic, and export the results as a standard `.m3u8` playlist file.

## Install

```bash
npm install
npx playwright install chromium
```

## Scrape a Live Stream Page

```bash
npm run sniff -- --url https://example.com/live --name "Example Live"
```

The command writes a playlist file to `output/<hostname>.m3u8` by default.

## Useful Options

```bash
node scripts/scrape-live-stream.js \
  --url https://example.com/live \
  --name "Example Live" \
  --output output/example-live.m3u8 \
  --delay 12000 \
  --wait-for ".player"
```

- `--url`: The webpage to inspect.
- `--name`: The channel name written into the playlist.
- `--output`: The path of the generated `.m3u8` file.
- `--delay`: Extra time to wait after page load so late network requests can be captured.
- `--wait-for`: A selector to wait for before collecting the final page content.

## Existing Demo Page

The simple demo player in `index.html`, `app.js`, and `style.css` is still available if you want to test local channels in a browser.
